<h1>🚌 Listado de Buses</h1>

<a href="index.php?page=Mantenimientos-Buses-Formulario&mode=INS">
    ➕ Nuevo Bus
</a>

<br><br>

<table border="1" cellpadding="8" cellspacing="0" width="100%">
    <thead style="background-color: #333; color: white;">
        <tr>
            <th>ID</th>
            <th>Placa</th>
            <th>Tipo</th>
            <th>Estado</th>
            <th>Acciones</th>
        </tr>
    </thead>

    <tbody>

        {{foreach buses}}
        <tr>
            <td>{{id}}</td>
            <td><strong>{{placa}}</strong></td>
            <td>{{tipo}}</td>
            <td>
                <span style="color: green; font-weight: bold;">
                    {{estado}}
                </span>
            </td>
            <td>

                <!-- VER -->
                <a href="index.php?page=Mantenimientos-Buses-Formulario&mode=DSP&id={{id}}">
                    👁️ Ver
                </a>

                |

                <!-- EDITAR -->
                <a href="index.php?page=Mantenimientos-Buses-Formulario&mode=UPD&id={{id}}">
                    ✏️ Editar
                </a>

                |

                <!-- ELIMINAR -->
                <a href="index.php?page=Mantenimientos-Buses-Formulario&mode=DEL&id={{id}}"
                   onclick="return confirm('¿Seguro que deseas eliminar este bus?');"
                   style="color: red;">
                    🗑️ Eliminar
                </a>

            </td>
        </tr>
        {{endfor buses}}
        

        {{ifnot buses}}
        <tr>
            <td colspan="5" style="text-align: center; color: gray;">
                ⚠️ No hay buses registrados
            </td>
        </tr>
        {{endifnot buses}}

        

    </tbody>
</table>
<br>

<div style="text-align:center; margin-top:20px;">
    <a href="index.php?page=Mantenimientos-Dashboard-Dashboard"
       style="
        display:inline-block;
        padding:12px 20px;
        background:linear-gradient(135deg, #6c757d, #495057);
        color:white;
        text-decoration:none;
        border-radius:4px;
        font-weight:bold;
        transition:0.3s;
    ">
        ⬅ Volver al Dashboard
    </a>
</div>