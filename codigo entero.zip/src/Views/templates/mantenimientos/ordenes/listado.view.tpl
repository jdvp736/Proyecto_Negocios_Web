<h1>📦 Listado de Órdenes</h1>

<a href="index.php?page=Mantenimientos-Ordenes-Formulario&mode=INS">
    ➕ Nueva Orden
</a>

<br><br>

<table border="1" cellpadding="8" cellspacing="0" width="100%">
    <thead style="background-color: #333; color: white;">
        <tr>
            <th>ID</th>
            <th>Usuario</th>
            <th>Total</th>
            <th>Estado</th>
            <th>Fecha</th>
            <th>Acciones</th>
        </tr>
    </thead>

    <tbody>

        {{foreach ordenes}}
        <tr>
            <td>{{id}}</td>

            <td><strong>{{nombre}}</strong></td>

            <td>
                <span style="color: blue; font-weight: bold;">
                    L. {{total}}
                </span>
            </td>

            <td>
                <span style="color: green; font-weight: bold;">
                    {{estado}}
                </span>
            </td>

            <td>{{fecha}}</td>

            <td>

                <!-- VER -->
                <a href="index.php?page=Mantenimientos-Ordenes-Formulario&mode=DSP&id={{id}}">
                    👁️ Ver
                </a>

                |

                <!-- EDITAR -->
                <a href="index.php?page=Mantenimientos-Ordenes-Formulario&mode=UPD&id={{id}}">
                    ✏️ Editar
                </a>

                |

                <!-- ELIMINAR -->
                <a href="index.php?page=Mantenimientos-Ordenes-Formulario&mode=DEL&id={{id}}"
                   onclick="return confirm('¿Seguro que deseas eliminar esta orden?');"
                   style="color: red;">
                    🗑️ Eliminar
                </a>

            </td>
        </tr>
        {{endfor ordenes}}

        {{ifnot ordenes}}
        <tr>
            <td colspan="6" style="text-align: center; color: gray;">
                ⚠️ No hay órdenes registradas
            </td>
        </tr>
        {{endifnot ordenes}}

    </tbody>
</table>

<div style="text-align:center; margin-top:20px;">
    <a href="index.php?page=Mantenimientos-Dashboard-Dashboard"
       style="
        display:inline-block;
        padding:12px 20px;
        background:linear-gradient(135deg, #6c757d, #495057);
        color:white;
        text-decoration:none;
        border-radius:4px;
        font-weight:bold;
        transition:0.3s;
    ">
        ⬅ Volver al Dashboard
    </a>
</div>